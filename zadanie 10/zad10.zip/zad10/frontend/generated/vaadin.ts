import './vaadin-featureflags.ts';

import './index';

import 'Frontend/generated/jar-resources/vaadin-dev-tools.js';
