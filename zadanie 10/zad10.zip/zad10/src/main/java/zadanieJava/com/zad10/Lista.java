package zadanieJava.com.zad10;

import javax.swing.*;

public class Lista {
    public JPanel panel1;
    public JTextArea textArea1;
     public JTextPane textPane1;
}
