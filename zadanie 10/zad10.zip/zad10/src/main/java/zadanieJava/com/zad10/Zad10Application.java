package zadanieJava.com.zad10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zad10Application {

	public static void main(String[] args) {
		SpringApplication.run(Zad10Application.class, args);
	}

}
